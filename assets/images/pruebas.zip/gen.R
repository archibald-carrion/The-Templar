# Usage:
# Rscript gen.R --riders <riders> --drivers <drivers> --size <size> \
# --ride-prob <ride-prob> --social-prob <social-prob> --social-low <low> \
# --social-high <high> --seed <seed>
# Generates test cases for algo.R given the following inputs:
#   <riders> (Rider count)
#   <drivers> (Driver count)
#   <size> (Sample count)
#   <ride-prob> (Probability of a ride being considered)
#   <social-prob> (Probability of a rider having social importance discount)
#   <low> (Minimum social discount for riders)
#   <high> (Maximum social discount for riders)
#   <seed> (Seed for random generation)
# Writes the test cases as such:
#   <1:size>.<'org'|'pre'>.riders.csv (Riders table)
#   <1:size>.<'org'|'pre'>.rides.csv (Rides table)
#   <1:size>.pre.profit (Minimum required profit when pre-processing)

# === Libraries ===
print("=== Libraries ===")
library(stats) # General statistic utils
library(DescTools) # Descriptive statistic utils
library(magrittr) # Pipe function

# === Input ===
print("=== Input ===")

cmd <- R.utils::commandArgs(asValues=TRUE)

print("Arguments passed from command line:")
print(cmd)

# Sanitize command line arguments
stopifnot(!is.null(cmd$args))
stopifnot(!is.null(cmd$riders))
stopifnot(!is.null(cmd$drivers))
stopifnot(!is.null(cmd$size))

stopifnot(!is.null(cmd$"ride-prob"))
stopifnot(!is.null(cmd$"social-prob"))
stopifnot(!is.null(cmd$"social-low"))
stopifnot(!is.null(cmd$"social-high"))

stopifnot(!is.null(cmd$seed))

# Fix datatypes
cmd$riders <- as.integer(cmd$riders)
cmd$drivers <- as.integer(cmd$drivers)
cmd$size <- as.integer(cmd$size)

cmd$"ride-prob" <- as.numeric(cmd$"ride-prob")
cmd$"social-prob" <- as.numeric(cmd$"social-prob")
cmd$"social-low" <- as.numeric(cmd$"social-low")
cmd$"social-high" <- as.numeric(cmd$"social-high")

cmd$seed <- as.integer(cmd$seed)

# Sanitize it
stopifnot(cmd$riders > 0)
stopifnot(cmd$drivers > 0)
stopifnot(cmd$size > 0)

stopifnot(cmd$"ride-prob" > 0 && cmd$"ride-prob" <= 1)
stopifnot(cmd$"social-prob" >= 0 && cmd$"social-prob" <= 1)

stopifnot(cmd$"social-low" >= 0 && cmd$"social-low" <= 1)
stopifnot(cmd$"social-high" >= 0 && cmd$"social-high" <= 1)
stopifnot(cmd$"social-low" <= cmd$"social-high")

# === Generation ===
print("=== Generation ===")

print(paste0("Riders :", cmd$riders))
print(paste0("Drivers :", cmd$drivers))
print(paste0("Sample size: ", cmd$size))
print(paste0("Ride probability: ", cmd$"ride-prob"))
print(paste0("Social discount probability: ", cmd$"social-prob"))
print(
  paste0(
    "Social discount between ", cmd$"social-low", "% and ", cmd$"social-high", "%"
    )
)
print(paste0("Seed: ", cmd$seed))

# Fix the seed
set.seed(cmd$seed)

for (index in 1:cmd$size) {
    # Generate riders
    riders <- data.frame(
        Rider = as.factor(1:cmd$riders),
        Affordability = rbinom(cmd$riders, 20, 0.25),
        Importance = replicate(
          cmd$riders,
          if (
            sample.int(
              n=2, size=1, prob=c(cmd$"social-prob", 1-cmd$"social-prob")
            ) == 1
          ) runif(n=1, min=cmd$"social-low", max=cmd$"social-high") else 0 
        )
    )

    # Generate rides for all pairs
    # Keep a subset of them according to edge density
    rides <- subset(
        expand.grid(
            Rider = as.factor(1:cmd$riders), 
            Driver = as.factor(1:cmd$drivers)
        ), replicate(
            cmd$riders * cmd$drivers, 
            sample.int(n=2, size=1, prob=c(cmd$"ride-prob", 1-cmd$"ride-prob")) == 1
        )
    )
    rides$"Price" = rbinom(NROW(rides), 20, 0.5)

    # Generate two variants based on preprocessing:
    # ~ Original
    org_rides <- data.frame(rides)

    # ~ Preprocessed
    pre_rides <- merge(
        riders[, c("Rider", "Importance")], 
        rides, by=c("Rider")
    )

    loss <- sum(
      pre_rides$"Price" - round(pre_rides$"Price" * (1 - pre_rides$"Importance"))
    )
  
    pre_rides$"Price" <- round(pre_rides$"Price" * (1 - pre_rides$"Importance"))
    pre_rides$"Importance" <- NULL

    # Write the riders to files
    write.csv(riders, paste0(index,".riders.csv"))
    
    # Write each variant's rides to files
    write.csv(org_rides, paste0(index,".rides.org.csv"))
    write.csv(pre_rides, paste0(index,".rides.pre.csv"))
    
    # Write the net loss for the preprocessing variant to a file
    cat(loss,file=paste0(index,".loss"))

    # All is done
    print(paste0("Finished sample #", index))
}
