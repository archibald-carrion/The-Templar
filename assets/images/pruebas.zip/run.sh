#!/bin/bash

# === Usage ===
# ./run.sh <base> <count>
# Runs the algo.R algorithm on a batch of inputs
# in the form of
#   <base + 1:count>.riders.csv"
#   <base + 1:count>.rides.<'org'|'pre'>.csv"
#   <base + 1:count>.loss"

# === Script ===
# Sanitize missing inputs
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <count>"
    echo "<count> is the amount of tests to run"
    echo "Files must be in the form:"
    echo "  <1:count>.riders.csv for the riders table"
    echo "  <1:count>.rides.<'org'|'pre'>.csv for the pricing table"
    echo "  <1:count>.loss for price loss (on preprocessed pricings)"
    exit 1
fi

# Sanitize invalid base
if ! [[ $1 =~ ^[1-9][0-9]*$ ]] ; then
   echo "<base> must be a positive number" >&2; exit 1
fi

# Sanitize invalid count
if ! [[ $2 =~ ^[1-9][0-9]*$ ]] ; then
   echo "<count> must be a positive number" >&2; exit 1
fi


# Invoke batch call
for index in $(seq $1 $(($1 + $2 - 1)));
  do
    # Original version
    echo "Scheduling trial #${index} (original)"
    nohup Rscript algo.R --riders "${index}.riders" --rides "${index}.rides.org" \
    --profit 0 --out "${index}.out.org" > "${index}.org.log" &
    
    # Pre-processed version
    echo "Scheduling trial #${index} (pre-processed)"
    nohup Rscript algo.R --riders "${index}.riders" --rides "${index}.rides.pre" \
    --profit $(cat "${index}.loss") --out "${index}.out.pre" > "${index}.pre.log" &
  done
