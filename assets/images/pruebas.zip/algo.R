# Usage:
# Rscript algo.R --riders <riders> --rides <rides> --profit <profit> --out <out>
# Solves the single-objective ILP described in 
# the paper, given the following inputs:
#   ./<riders>.csv (Rider table)
#   ./<rides>.csv (Pricing table)
# Writes the solution (if found) to ./<out>.csv

# === Libraries ===
print("=== Libraries ===")
library(stats) # General statistic utils
library(DescTools) # Descriptive statistic utils
library(magrittr) # Pipe function
library(lpSolve) # Linear programming backend

# === Input ===
print("=== Input ===")

cmd <- R.utils::commandArgs(asValues=TRUE)

print("Arguments passed from command line:")
print(cmd)

# Sanitize command line arguments
stopifnot(!is.null(cmd$args))
stopifnot(!is.null(cmd$riders))
stopifnot(!is.null(cmd$rides))
stopifnot(!is.null(cmd$profit))
stopifnot(!is.null(cmd$out))

cmd$earnings <- as.integer(cmd$profit)
stopifnot(cmd$profit >= 0)

# Sanitize matrices
# ~~~ Riders
riders <- read.csv(paste0(cmd$riders, ".csv"))

# Missing columns
stopifnot(!is.null(riders$Rider))
stopifnot(!is.null(riders$Affordability))
stopifnot(!is.null(riders$Affordability))

# Fix datatypes
riders$Rider <- as.factor(as.integer(riders$Rider))
riders$Affordability <- as.integer(riders$Affordability)

# Missing entries
stopifnot(sum(is.na(riders$Rider)) == 0)
stopifnot(sum(is.na(riders$Affordability)) == 0)

print(
  paste0(
    "Rider table: ", nlevels(riders$Rider), " riders"
  )
)

# ~~~ Possible rides
possible_rides <- read.csv(paste0(cmd$rides, ".csv"))

# Missing columns
stopifnot(!is.null(possible_rides$Rider))
stopifnot(!is.null(possible_rides$Driver))
stopifnot(!is.null(possible_rides$Price))

# Fix datatypes
possible_rides$Rider <- as.factor(as.integer(possible_rides$Rider))
possible_rides$Driver <- as.factor(as.integer(possible_rides$Driver))
possible_rides$Price <- as.integer(possible_rides$Price)

# Missing entries
stopifnot(sum(is.na(riders$Rider)) == 0)
stopifnot(sum(is.na(riders$Affordability)) == 0)

print(
  paste0(
    "Pricing matrix: ", nlevels(possible_rides$Rider), " riders, ",
    nlevels(possible_rides$Driver), " drivers"
  )
)

# ~~ Coherence between the two
stopifnot(levels(riders$Rider) == levels(possible_rides$Rider))

# === Variable encodings ===
print("=== Variable encodings ===")

# x_{i + (j - 1) * rider} is the binary pairing choice for the i-th rider and the j-th driver
possible_rides$"Choice variable" <- 1:NROW(possible_rides)

print(
  paste0(
    "Pairing choice variables: ", 
    min(possible_rides$"Choice variable"), " - ", max(possible_rides$"Choice variable")
  )
)

# x_{rider*drivers + p} is the price assigned to the p-th rider on their ride
riders$"Price variable" <- riders$Rider %>% levels() %>% as.numeric() +
  NROW(possible_rides)

print(
  paste0(
    "Riders' price variables: ", 
    min(riders$"Price variable"), " - ", max(riders$"Price variable")
  )
)

# === Objective Function ===
print("=== Objective Function ===")

# Pick a factor bigger than the sum of all greatest prices as the ultimate penalty
# It can serve to punish picking an unfeasible pairing or override optimization
global_penalty <- sum(riders$Affordability) + 1

print(paste0("Global penalty: ", global_penalty))

# Maximize the pairings between riders and drivers
# and minimize the sum of all prices
# Min: Sum Y(P) - Sum X(P,C) * Global Penalty for all P, C
f.obj <- rep(0, NROW(possible_rides) + NROW(riders))
f.obj[riders$"Price variable"] <- 1
f.obj[possible_rides$"Choice variable"] <- -1 * global_penalty

# === Constraint encodings ===
print("=== Constraint encodings ===")

# Choice constraints: Pairing choice must be binary
choice_constraints <- merge(
  possible_rides[, c("Rider", "Driver", "Choice variable")], 
  data.frame("Lower" = c(TRUE, FALSE))
)
choice_constraints$Index <- 1:NROW(choice_constraints)

print(
  paste0(
    "Pairing choices' binary constraints: ", 
    min(choice_constraints$Index), " - ", max(choice_constraints$Index)
  )
)

# Unique riders: Any driver might have at most one rider assigned
rider_constraints <- data.frame(
  Rider = possible_rides$Rider %>% levels() %>% as.integer(),
  Index = 1:length(levels(possible_rides$Rider)) +
    NROW(choice_constraints) # Offset from previous constraints
)

print(
  paste0(
    "Pairing choices' unique-rider-per-driver constraints: ", 
    min(rider_constraints$Index), " - ", max(rider_constraints$Index)
  )
)

# Unique drivers: Any rider might have at most one driver assigned
driver_constraints <- data.frame(
  Driver = possible_rides$Driver %>% levels() %>% as.integer(),
  Index = 1:length(levels(possible_rides$Driver)) +
    NROW(rider_constraints) + NROW(choice_constraints) # Offset
)

print(
  paste0(
    "Pairing choices' unique-driver-per-rider constraints: ", 
    min(driver_constraints$Index), " - ", max(driver_constraints$Index)
  )
)

# Pricing constraints: A rider may only be charged a non-negative price as 
# high as what they can afford
pricing_constraints <- merge(
  riders[, c("Rider"), drop=FALSE],
  data.frame("Lower" = c(TRUE, FALSE))
)
pricing_constraints$Index <- 1:NROW(pricing_constraints) + 
  NROW (driver_constraints) + NROW(rider_constraints) + NROW(choice_constraints) # Offset

print(
  paste0(
    "Rider pricings' non-negative-below-affordability constaints: ", 
    min(pricing_constraints$Index), " - ", max(pricing_constraints$Index)
  )
)

# === Constraint linear system ===
f.con <- matrix(
  # By default, all variables are discarded
  0,
  # Subject variables = pairing choice + rider pricing
  ncol = NROW(possible_rides) + NROW(riders),
  # Constraints = 
  # choice constraints + 
  # unique rider choice constraints +
  # unique driver constraints +
  # pricing constraints + 
  # profit constraint (non-negative net profit)
  nrow = NROW(choice_constraints) +
    NROW(rider_constraints) +
    NROW(driver_constraints) +
    NROW(pricing_constraints) +
    1
)

f.rhs <- matrix(nrow=NROW(f.con), ncol=1)
f.dir <- matrix(nrow=NROW(f.con), ncol=1)

print(
  paste0(
    "Constraint matrix: ", NROW(f.con) , " rows, ", NCOL(f.con), " columns"
  )
)

# ~~~ Binary rider-driver pairing choice ~~~
# 0 <= x_{pairing for P, C} <= 1
f.con[
  cbind(choice_constraints$Index, choice_constraints$"Choice variable")
] <-  1
f.dir[choice_constraints$Index] <- ifelse(choice_constraints$Lower, "<=", ">=")
f.rhs[choice_constraints$Index] <- ifelse(choice_constraints$Lower, 1, 0)

# ~~~ Unique rider per driver ~~~
# Sum (x_{pairing for P, C} with fixed P) <= 1
choices_per_constraint <- merge(
  possible_rides[, c("Rider", "Choice variable")], 
  rider_constraints[, c("Rider", "Index")], by ="Rider"
)[, c("Index", "Choice variable")]

f.con[
  cbind(choices_per_constraint$Index, choices_per_constraint$"Choice variable")
] <-  1
f.dir[choices_per_constraint$Index] <- "<="
f.rhs[choices_per_constraint$Index] <- 1

# ~~~ Unique driver per rider ~~~
# Sum (x_{pairing for P, C} with fixed C) <= 1
choices_per_constraint <- merge(
  possible_rides[, c("Driver", "Choice variable")], 
  driver_constraints[, c("Driver", "Index")], by ="Driver"
)[, c("Index", "Choice variable")]

f.con[
  cbind(choices_per_constraint$Index, choices_per_constraint$"Choice variable")
] <-  1
f.dir[choices_per_constraint$Index] <- "<="
f.rhs[choices_per_constraint$Index] <- 1

rm(choices_per_constraint)

# ~~~ Affordable pricing ~~~
# 0 <= x_{price for P} <= A(P) * Sum (Picked(P, C) for all C)

# Lower bound: 0 <= x_{price for P}
boundary_constraints <- subset(
  pricing_constraints, pricing_constraints$Lower == TRUE
)[, c("Index", "Rider")]

prices_per_constraint <- merge(
  riders[, c("Rider", "Price variable")], 
  boundary_constraints, by ="Rider"
)[, c("Index", "Price variable")]

f.con[
  cbind(prices_per_constraint$Index, prices_per_constraint$"Price variable")
] <- 1
f.dir[boundary_constraints$Index] <- ">="
f.rhs[boundary_constraints$Index] <- 0

# Higher bound: x_{price for P} <= A(P) * Sum (Picked(P, C) for all C)
# x_{price for P} - A(P) * Picked(P, 1) - ... - A(P) * Picked(P, drivers) <= 0
boundary_constraints <- subset(
  pricing_constraints, pricing_constraints$Lower == FALSE
)[, c("Index", "Rider")]

prices_per_constraint <- merge(
  riders[, c("Rider", "Price variable")], 
  boundary_constraints, by ="Rider"
)[, c("Index", "Price variable")]

f.con[
  cbind(prices_per_constraint$Index, prices_per_constraint$"Price variable")
] <- 1

choices_per_constraint <- merge(
  boundary_constraints, riders, by ="Rider"
)[, c("Affordability", "Index", "Rider")]

choices_per_constraint <- merge(
  possible_rides[,c("Rider", "Choice variable")], 
  choices_per_constraint, by ="Rider"
)[, c("Affordability", "Index", "Choice variable")]

f.con[
  cbind(choices_per_constraint$Index, choices_per_constraint$"Choice variable")
] <- -1 * choices_per_constraint$Affordability

f.dir[boundary_constraints$Index] <- "<="
f.rhs[boundary_constraints$Index] <- 0

rm(boundary_constraints, choices_per_constraint, prices_per_constraint)

# ~~~ Minimum net profit ~~~
# Sum (Profit(P) for all P) >= profit
# Sum (Price(P) - Cost(P) for all P) >= profit
# Sum (Price(P) for all P) - Sum (Picked(P,C) * Cost(P,C) for all P, C) >= profit
f.con[NROW(f.con), riders$"Price variable"] <- 1
f.con[NROW(f.con), possible_rides$"Choice variable"] <- -1 * possible_rides$Price
f.dir[NROW(f.con)] <- ">="
f.rhs[NROW(f.con)] <- cmd$profit

# === Linear program evaluation ===
print("=== Linear program evaluation ===")

# Evaluate integer linear program, never timing out
solution <- lp("min", f.obj, f.con, f.dir, f.rhs, all.int=TRUE)

# Check it. Abort if wrong
print("Solution summary:")
print(solution)

if(solution$status != 0) {
  stop("No feasable solution found")
}

# Map the variables back to riders, drivers, and pricing
# 1. Filter for valid pairings
results <- subset(
  possible_rides,
  solution$solution[possible_rides$"Choice variable"] > 0
)[, c("Rider", "Driver", "Price")]

# 2. Cross-reference with riders
results <- merge(
  results, 
  riders[, c("Rider", "Affordability", "Price variable")], 
  by = "Rider"
)

# 3. Calculate relevant offsets
results$Charged <- solution$solution[results$"Price variable"]
results$Difference <- results$Charged - results$Price

# 4. Forego unnecessary columns
results$"Price variable" <- NULL

print("Result summary:")
print(results)

print("Sanity check:")
print(
  data.frame(
    "Duplicate drivers" = sum(table(results$Driver) > 1),
    "Duplicate riders" = sum(table(results$Rider) > 1),
    "Negative prices" = sum(results$Charged < 0),
    "Prices above affordability" = sum(results$Charged > results$Affordability),
    "Net difference / profit" = sum(results$Difference),
    check.names = FALSE
  )
)

# === Output ===
print(paste0("Writing solution to ", cmd$out,".csv"))
write.csv(results, paste0(cmd$out,".csv"))
